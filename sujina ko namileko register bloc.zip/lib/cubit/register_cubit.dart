import 'package:flutter_bloc/flutter_bloc.dart';

// Define states for registration
abstract class RegisterState {}

class RegisterInitial extends RegisterState {}

class RegisterLoading extends RegisterState {}

class RegisterSuccess extends RegisterState {}

class RegisterError extends RegisterState {
  final String message;
  RegisterError(this.message);
}

// Register Cubit
class RegisterCubit extends Cubit<RegisterState> {
  RegisterCubit() : super(RegisterInitial());

  // Method to handle user registration logic
  void register(
      String fullName, String email, String password, String confirmPassword) {
    if (fullName.isEmpty ||
        email.isEmpty ||
        password.isEmpty ||
        confirmPassword.isEmpty) {
      emit(RegisterError("All fields are required"));
      return;
    }

    if (!RegExp(r"^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]+").hasMatch(email)) {
      emit(RegisterError("Please enter a valid email address"));
      return;
    }

    if (password.length < 6) {
      emit(RegisterError("Password should be at least 6 characters"));
      return;
    }

    if (password != confirmPassword) {
      emit(RegisterError("Passwords do not match"));
      return;
    }

    // Simulate a loading state while the registration process is happening
    emit(RegisterLoading());

    // Simulating a network request or registration logic
    Future.delayed(const Duration(seconds: 2), () {
      // Assuming registration is successful
      emit(RegisterSuccess());
    });
  }
}
