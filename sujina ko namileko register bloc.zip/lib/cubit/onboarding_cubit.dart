import 'package:flutter_bloc/flutter_bloc.dart';

class OnboardingCubit extends Cubit<int> {
  OnboardingCubit() : super(0);

  void nextPage() => emit(state + 1); // Move to the next page
  void setPage(int index) => emit(index); // Set a specific page index
}
