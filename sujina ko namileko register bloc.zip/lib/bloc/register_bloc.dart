import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:sprint_1/bloc/register_event.dart';
import 'package:sprint_1/bloc/register_state.dart';

class RegisterBloc extends Bloc<RegisterEvent,RegisterState>{
  RegisterBloc() : super(RegisterInitial());
} 


// import 'package:bloc/bloc.dart';
// import 'package:equatable/equatable.dart';
// import 'package:sprint_1/cubit/register_cubit.dart' as cubit;
// import 'register_event.dart';
// import 'register_state.dart';

// class RegisterBloc extends Bloc<RegisterEvent, RegisterState> {
//   RegisterBloc() : super(RegisterInitial());

//   Stream<RegisterState> mapEventToState(RegisterEvent event) async* {
//     if (event is RegisterSubmitted) {
//       // Start loading state
//       yield cubit.RegisterLoading();

//       // Perform validation
//       if (event.fullName.isEmpty ||
//           event.email.isEmpty ||
//           event.password.isEmpty ||
//           event.confirmPassword.isEmpty) {
//         yield RegisterError("All fields are required");
//         return;
//       }

//       // Validate Email
//       if (!RegExp(r"^[a-zA-Z0-9]+@[a-zA-Z0-9]+\.[a-zA-Z]+")
//           .hasMatch(event.email)) {
//         yield RegisterError("Please enter a valid email address");
//         return;
//       }

//       // Validate Password
//       if (event.password.length < 6) {
//         yield RegisterError("Password should be at least 6 characters");
//         return;
//       }

//       // Check if passwords match
//       if (event.password != event.confirmPassword) {
//         yield RegisterError("Passwords do not match");
//         return;
//       }

//       // Simulate a network request or registration logic
//       await Future.delayed(const Duration(seconds: 2));

//       // Assuming registration is successful
//       yield RegisterSuccess();
//     }
//   }
// }
