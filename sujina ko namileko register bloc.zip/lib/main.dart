import 'package:flutter/material.dart';
import 'package:sprint_1/services/service_locator.dart';
import 'package:sprint_1/app.dart'; // Import MyApp

void main() {
  setupLocator(); // Setup for service locator

  runApp(const MyApp());
}
