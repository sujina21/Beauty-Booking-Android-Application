import 'package:get_it/get_it.dart';
import 'package:sprint_1/cubit/login_cubit.dart';
import 'package:sprint_1/cubit/onboarding_cubit.dart';

final GetIt locator = GetIt.instance;

void setupLocator() {
  locator.registerLazySingleton(() => OnboardingCubit());
  // locator.registerLazySingleton(() => RegisterCubit());
  locator.registerLazySingleton(() => LoginCubit());
}