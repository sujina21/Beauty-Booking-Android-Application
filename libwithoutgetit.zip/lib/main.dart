import 'package:flutter/material.dart';
import 'package:sprint_1/app.dart';

void main() {
  runApp(const MyApp());
}
